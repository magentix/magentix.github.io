<?php

/**
 * Class Magentix_DynamicJs_JsController
 */
class Magentix_DynamicJs_JsController extends Mage_Core_Controller_Front_Action
{
    /**
     * Index Action
     */
    public function indexAction()
    {
        /** @var Mage_Core_Model_Date $date */
        $date = Mage::getModel('core/date');
        /** @var string $gmtDate */
        $gmtDate = $date->date("D, d M Y H:i:s") . ' GMT';

        $this->getResponse()->setHeader('Content-Type', 'application/javascript');
        $this->getResponse()->setHeader('Last-Modified', $gmtDate, true);
        $this->getResponse()->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0', true);
        $this->getResponse()->setHeader('Pragma', 'no-cache', true);
        $this->getResponse()->setHeader('Expires', 'Sat, 26 Jul 1997 05:00:00 GMT', true);

        $this->loadLayout(false);
        $this->renderLayout();
    }
}
