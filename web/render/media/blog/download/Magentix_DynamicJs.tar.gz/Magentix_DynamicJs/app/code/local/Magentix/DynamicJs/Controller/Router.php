<?php

/**
 * Class Magentix_DynamicJs_Controller_Router
 */
class Magentix_DynamicJs_Controller_Router extends Mage_Core_Controller_Varien_Router_Standard
{
    /**
     * Initialize Controller Router
     *
     * @param Varien_Event_Observer $observer
     *
     * @return void
     */
    public function initControllerRouters($observer)
    {
        /** @var Mage_Core_Controller_Varien_Front $front */
        $front = $observer->getEvent()->getFront();

        $front->addRouter('dynamicjs', $this);
    }

    /**
     * New route for Dynamic Js
     *
     * @param Zend_Controller_Request_Http $request
     *
     * @return bool
     */
    public function match(Zend_Controller_Request_Http $request)
    {
        $path = trim($request->getPathInfo(),'/');

        if ($path === 'dynamic/script.js') {
            $request->setModuleName('dynamicjs')
                ->setControllerName('js')
                ->setActionName('index');

            return true;
        }

        return false;
    }
}