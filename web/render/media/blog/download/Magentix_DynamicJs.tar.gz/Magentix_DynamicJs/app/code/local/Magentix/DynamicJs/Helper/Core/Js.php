<?php

/**
 * Class Magentix_DynamicJs_Helper_Core_Js
 */
class Magentix_DynamicJs_Helper_Core_Js extends Mage_Core_Helper_Js
{
    /**
     * Retrieve JS translator initialization javascript
     *
     * @return string
     * @throws Mage_Core_Model_Store_Exception
     */
    public function getTranslatorScript()
    {
        if (Mage::app()->getStore()->isAdmin()) {
            return parent::getTranslatorScript();
        }

        return '';
    }
}

